public interface Drugable {
    void addDrug(Drug drug);
    boolean check();
}
