public interface IType {
    public String type();
}
