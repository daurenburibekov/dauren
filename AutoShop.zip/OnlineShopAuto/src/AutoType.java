public enum AutoType {
    HATCHBACK,SEDAN,JEEP
}
