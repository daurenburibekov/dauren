public interface IClient {
    public void subscribe(Auto auto);
    public void unSubscribe(Auto auto);
    public void update(boolean a, String s);
}
